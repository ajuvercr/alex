
use error_chain::ChainedError;
use eva::Result;
use eva::database::Database;
use eva::errors::*;
use eva::configuration::{SchedulingStrategy, Configuration};

pub mod my_db;

mod errors {
    error_chain! {
        errors {
            Read(what: String) {
                description("configuration parsing error")
                display("An error occurred while trying to read {}", what)
            }
            FileCreation(config_name: String) {
                description("file creation error while reading configuration")
                display("I could not create {}", config_name)
            }
            ShellExpansion(what: String) {
                description("shell expansion error while reading configuration")
                display("An error occurred while trying to expand the configuration of {}", what)
            }
            DatabaseConnect(path: String) {
                description("database connection error")
                display("I could not connect to the database ({})", path)
            }
            Default(what: String) {
                description("setting defaults error while reading configuration")
                display("An error occurred while trying to set the default configuration of {}",
                        what)
            }
        }
    }
}